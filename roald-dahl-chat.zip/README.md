# Chat with Roald Dahl

Simple AI chat website.

## Setup

1. Push this repo to GitHub.
2. Import it into Vercel or Netlify.
3. Set your OPENAI_API_KEY in Environment Variables.
4. Deploy → frontend available at your URL.
