# Chat with Roald Dahl

A simple AI chat website hosted on Vercel.

## 🚀 Setup
1. Clone this repo to your GitHub.
2. Import the repo into [Vercel](https://vercel.com).
3. In Vercel → Project Settings → Environment Variables:
   - Add `OPENAI_API_KEY` = your API key.
4. Deploy.
5. Your site will be live at `https://your-app.vercel.app`.

## 🌐 Custom Domain
- In Vercel Project Settings → Domains → Add your domain.
- Update DNS (CNAME → `cname.vercel-dns.com`).
